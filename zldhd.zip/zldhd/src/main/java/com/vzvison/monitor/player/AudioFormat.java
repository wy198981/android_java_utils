package com.vzvison.monitor.player;

public class AudioFormat {
	public static final int G711	= 211;
	public static final int G726	= 212;
	public static final int G729	= 213;
	public static final int NVCT	= 214;
	
}
