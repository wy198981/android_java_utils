package com.vzvison;

public enum ViewSetInnerType {
    Vedio("视频"),Image("图片");
    private String name = "";
    ViewSetInnerType(String text)
    {
    	name  = text;
    }
}
