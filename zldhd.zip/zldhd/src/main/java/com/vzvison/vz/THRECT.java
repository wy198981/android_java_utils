package com.vzvison.vz;

public class THRECT {
	  public int left;	/**<左*/
	   public  int top;	/**<上*/
	   public int right;	/**<右*/
	   public int bottom;	/**<下*/
}
