//package com.zld.local.bean;
//
//import java.util.List;
//
//import com.zld.local.db.Order_tb;
//
//public class synchroUpdateInfo {
//
//	// {"orders":[],"relation":[{local:9d19c59a-f87f-427e-8365-ff0e199d0bb3,line:786927},{}],"maxid":786927,"delOrderIds":786741,786742}
//	private List<Order_tb> orderss;
//
//	private List<Relation> relation;
//
//	private String maxid;
//
//	private String delOrderIds;
//
//	public void setOrders(List<Order_tb> orders) {
//		this.orderss = orders;
//	}
//
//	public List<Order_tb> getOrders() {
//		return this.orderss;
//	}
//
//	public void setRelation(List<Relation> relation) {
//		this.relation = relation;
//	}
//
//	public List<Relation> getRelation() {
//		return this.relation;
//	}
//
//	public void setMaxid(String maxid) {
//		this.maxid = maxid;
//	}
//
//	public String getMaxid() {
//		return this.maxid;
//	}
//
//	public void setDelOrderIds(String delOrderIds) {
//		this.delOrderIds = delOrderIds;
//	}
//
//	public String getDelOrderIds() {
//		return this.delOrderIds;
//	}
//
//	@Override
//	public String toString() {
//		return "synchroUpdateInfo [orderss=" + orderss + ", relation=" + relation + ", maxid=" + maxid + ", delOrderIds="
//				+ delOrderIds + "]";
//	}
//
//}
