//package com.zld.local.bean;
//
//import java.util.ArrayList;
//
//import com.zld.bean.AllOrder;
//
//public class LocalCurrentOrder {
//
//	private String count;
//	private String price;
//	private ArrayList<AllOrder> info;
//	public LocalCurrentOrder() {
//		super();
//	}
//	public String getCount() {
//		return count;
//	}
//	public void setCount(String count) {
//		this.count = count;
//	}
//	public String getPrice() {
//		return price;
//	}
//	public void setPrice(String price) {
//		this.price = price;
//	}
//	public ArrayList<AllOrder> getInfo() {
//		return info;
//	}
//	public void setInfo(ArrayList<AllOrder> info) {
//		this.info = info;
//	}
//	@Override
//	public String toString() {
//		return "HistoryOrder [count=" + count + ", price=" + price + ", info="+ info + "]";
//	}
//	
//	
//	
//}
