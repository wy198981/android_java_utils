//package com.zld.local.db;
//
//public class ComInfo_tb {
//
//	public String id;
//	public String minprice_unit;// 最小价格单位；
//
//	public ComInfo_tb(String id, String minprice_unit) {
//		super();
//		this.id = id;
//		this.minprice_unit = minprice_unit;
//	}
//
//	public ComInfo_tb() {
//		super();
//	}
//
//	@Override
//	public String toString() {
//		return "ComInfo_tb [id=" + id + ", minprice_unit=" + minprice_unit + "]";
//	}
//
//}
