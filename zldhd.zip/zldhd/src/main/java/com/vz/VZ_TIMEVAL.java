package com.vz;

public class VZ_TIMEVAL {
	  public int uTVSec;
	  public int uTVUSec;
}
